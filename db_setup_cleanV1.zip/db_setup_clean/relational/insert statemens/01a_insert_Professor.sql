DELETE FROM grad_db.Professor;

-- Insert data into Professor table
INSERT INTO Professor (name, lastname)
VALUES
    ('Dr.', 'Smith'),
    ('Dr.', 'Johnson'),
    ('Dr.', 'Williams'),
    ('Dr.', 'Brown'),
    ('Dr.', 'Davis'),
    ('Dr.', 'Martinez'),
    ('Dr.', 'Rodriguez'),
    ('Dr.', 'Garcia'),
    ('Dr.', 'Hernandez'),
    ('Dr.', 'Gonzalez');