USE grad_db;
-- Inserting records into ResearchWork_has_Graduate table
INSERT INTO grad_db.ResearchWork_has_Graduate (idResearchWork, idGraduate)
VALUES
    (1, 745207),
    (1, 297188),
    (2, 482750),
    (3, 245386),
    (4, 547657),
    (5, 898191),
    (6, 704363),
    (7, 227399),
    (8, 621100),
    (9, 832720);
